package com.example.owner.colorcodequiz;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

public class MenuActivity extends AppCompatActivity {
     private EditText setnum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        setnum = (EditText)findViewById(R.id.setnum) ;
    }



    public void CodetoColor(View view) {
        new AlertDialog.Builder(MenuActivity.this)
                .setTitle("Title")
                .setMessage("Message")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // OK button pressed
                        setnum.selectAll();
                        String num = setnum.getText().toString();
                        Intent intent = new Intent(MenuActivity.this, CodetoColorActivity.class);
                        intent.putExtra("getnumber", num);
                        startActivity(intent);
                    }
                }).show();

    }


    public void ColortoCode(View view) {
        new AlertDialog.Builder(MenuActivity.this)
                .setTitle("Title")
                .setMessage("Message")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // OK button pressed
                        setnum.selectAll();
                        String num = setnum.getText().toString();
                        Intent intent = new Intent(MenuActivity.this, ColortoCodeActivity.class);
                        intent.putExtra("getnumber", num);
                        startActivity(intent);
                    }
                }).show();

    }


    public void ColortoCode_practice(View view) {
        new AlertDialog.Builder(MenuActivity.this)
                .setTitle("title")
                .setMessage("message")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // OK button pressed
                        Intent intent = new Intent(MenuActivity.this, ColortoCode_practiceActivity.class);
                        startActivity(intent);
                    }
                }).show();

    }

    public void CodetoColor_practice (View view){
        new AlertDialog.Builder(MenuActivity.this)
                .setTitle("Title")
                .setMessage("Message")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // OK button pressed
                        Intent intent = new Intent(MenuActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                }).show();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
